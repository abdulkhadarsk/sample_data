# Python_workshop

Hands-on python workshop hosted: 

Topics covered: 

* Introduction to python library 
* Data cleaning 
* Exploratory data analysis 
* visualisation 


